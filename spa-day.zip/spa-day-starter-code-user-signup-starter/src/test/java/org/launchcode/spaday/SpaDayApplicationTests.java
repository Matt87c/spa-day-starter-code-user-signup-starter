package org.launchcode.spaday;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpaDayApplicationTests {

	@Test
	void contextLoads() {
	}

}
